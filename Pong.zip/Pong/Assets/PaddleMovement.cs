using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleMovement : MonoBehaviour
{
    public float speed = 0.5f;
    public bool isLeftPlayer = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // slide up
        if(isLeftPlayer == true){
            if(Input.GetKey(KeyCode.W)){
                // if we haven't reached the top limit
                if(transform.position.y < 5.0f){
                    Vector3 pos = transform.position;
                    pos.y += speed;
                    transform.position = pos;
                }
            }

            // slide down
            if(Input.GetKey(KeyCode.S)){
                // if we haven't reached the bottom limit
                if(transform.position.y > -3.0f){
                    Vector3 pos = transform.position;
                    pos.y -= speed;
                    transform.position = pos;
                }
            }
        }else{
            if(Input.GetKey(KeyCode.I)){
                // if we haven't reached the top limit
                if(transform.position.y < 5.0f){
                    Vector3 pos = transform.position;
                    pos.y += speed;
                    transform.position = pos;
                }
            }

            // slide down
            if(Input.GetKey(KeyCode.K)){
                // if we haven't reached the bottom limit
                if(transform.position.y > -3.0f){
                    Vector3 pos = transform.position;
                    pos.y -= speed;
                    transform.position = pos;
                }
            }
        }

    }
}
