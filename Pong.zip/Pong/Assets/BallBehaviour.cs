using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BallBehaviour : MonoBehaviour
{
    public float startSpeed = 20.0f;
    int rightPlayerScore = 0;
    int leftPlayerScore = 0;

    public GameObject scoreRightText;
    public GameObject scoreLeftText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)){
            GetComponent<Rigidbody>().AddForce(Random.onUnitSphere * startSpeed);
        }

        if(transform.position.x < -12.5f){
            rightPlayerScore += 1;
            scoreRightText.GetComponent<TMP_Text>().text = rightPlayerScore.ToString();

            transform.position = Vector3.zero;
            GetComponent<Rigidbody>().velocity = Vector3.zero;
            GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
        }

        if(transform.position.x > 12.5f){
            leftPlayerScore += 1;
            scoreLeftText.GetComponent<TMP_Text>().text = leftPlayerScore.ToString();

            transform.position = Vector3.zero;
            GetComponent<Rigidbody>().velocity = Vector3.zero;
            GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
        }

        Debug.Log(leftPlayerScore + " - " + rightPlayerScore);
    }
}
