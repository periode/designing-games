using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBehavior : MonoBehaviour
{
    public int initialSpeed = 100;
    public string ballName = "yolo";
    // Start is called before the first frame update
    void Start()
    {
        initialSpeed = 400;
        Vector3 startDirection = Random.onUnitSphere * initialSpeed;
        startDirection.z = 0;
        this.GetComponent<Rigidbody>().AddForce(startDirection, ForceMode.Acceleration);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter(Collision col){
        Debug.Log("collided with: " + col.gameObject.tag);
        string tag = col.gameObject.tag;

        if(tag == "Paddle"){
            // pitch-shift the sound effect
            this.GetComponent<AudioSource>().pitch = Random.Range(0f, 1f);
            this.GetComponent<AudioSource>().Play();
        }
    }
}
