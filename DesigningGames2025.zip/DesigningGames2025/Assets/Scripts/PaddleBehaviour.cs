using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleBehaviour : MonoBehaviour
{

    public bool isLeftPlayer = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isLeftPlayer == true){
            if(Input.GetKey(KeyCode.W) && transform.position.y < 3.7f){
                this.transform.position += Vector3.up * 0.01f;
            }

            if(Input.GetKey(KeyCode.S) && transform.position.y > -3.7f){
                this.transform.position += Vector3.down * 0.01f;
            }
        }else{
            if(Input.GetKey(KeyCode.O) && transform.position.y < 3.7f){
                this.transform.position += Vector3.up * 0.01f;
            }

            if(Input.GetKey(KeyCode.L) && transform.position.y > -3.7f){
                this.transform.position += Vector3.down * 0.01f;
            }
        }

    }
}
