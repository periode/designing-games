using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeBehavior : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        float r = Random.Range(-2, 2);
        if(r < 0){
        this.GetComponent<Transform>().position = new Vector3(-5, 0, 0);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
