using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoringZoneBehavior : MonoBehaviour
{

    int leftPlayerScore = 0;
    int rightPlayerScore = 0;
    public bool isLeftScoring = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // this gets called whenever something with a rigidbody enters the trigger collider
    public void OnTriggerEnter(Collider external){
        if(isLeftScoring){
            rightPlayerScore += 1;
            GameObject.Find("ScoreRight").GetComponent<TMP_Text>().text = rightPlayerScore.ToString();
        }else{
            leftPlayerScore += 1;
            GameObject.Find("ScoreLeft").GetComponent<TMP_Text>().text = leftPlayerScore.ToString();
        }

        Debug.Log("Score is now: " + leftPlayerScore + " - " + rightPlayerScore);

        GameObject.Find("Ball").GetComponent<Transform>().position = new Vector3(0, 0, 0);
    }
}
